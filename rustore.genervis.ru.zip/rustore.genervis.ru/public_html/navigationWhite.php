<style>
    .nav_custom{
        background: none !important;
    }
    .collapse.navbar-collapse{
        background: none !important;
    }
    .nav-link{
        color: black !important;
    }
</style>

<nav class="navbar navbar-expand-lg navbar-dark nav_custom">
  <div class="container" style="padding: 0px 0px;">
    <a class="navbar-brand" href="index.php"><img src="img/index/logo.svg" style="height: 30px; padding-left: 12px;"></a>
    <a class="navbar-brand" href="#"><img src="img/index/минцифры.svg" style="height: 30px; padding-left: 12px;"></a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" id="menu-index" aria-current="page" href="index.php"><b>Главная</b></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="menu-about" aria-current="page" href="chat.php">Ассистент</a>
        </li>
        
      </ul>
      <form class="d-flex" role="search">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>