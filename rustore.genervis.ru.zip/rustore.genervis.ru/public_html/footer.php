<img src="img/index/Vector.png" style="filter: hue-rotate(230deg);">
<div style="margin-top: -75px; display: flex; flex-direction:column; margin-right: 110px;">
    <div style="align-self: flex-end;">
        Консультант по документации<br/>
        на базе Искусственного интеллекта
    </div>
</div>