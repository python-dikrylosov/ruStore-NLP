<?
$text = urlencode(iconv("CP1251", "UTF-8", $_GET['text']));
if ($text) {
    $link = "http://translate.google.com/translate_tts?tl=RU&ie=UTF-8&q=" . $text;
    $mp3data = file_get_contents($link);
    $file = time() . ".mp3";
    file_put_contents($file, $mp3data);
}