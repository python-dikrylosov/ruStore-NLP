const btnAsk = document.querySelector('.btn-ask');
const btnOk = document.querySelector('.btn-ok');
const btnFormaty = document.querySelector('.btn-formaty');
const btnStop = document.querySelector('.btn-stop');
let wrapperVideo = document.getElementById('fon');
const videoSpace = document.getElementById('video-space');

const textArea = document.getElementById('textAreaExample6');


btnFormaty.addEventListener('click',function(){
  wrapperVideo.remove();
  videoSpace.insertAdjacentHTML('beforeend', `<video preload="auto" id="fon" autoplay="" controls=""><source src="videos/hello_first.mp4" type='video/webm; codecs="vp8, vorbis"' /></video>`); // И создаём видео внутри блока для видео
  wrapperVideo = document.getElementById('fon');
  wrapperVideo.play();
});

btnAsk.addEventListener('click',function(){
      
        var form = $('form')[1]; // You need to use standard javascript object here
        var formData = new FormData(form);
        var area = formData.get('userQuestion');
        console.log(form);
        console.log(area);

    var formdata = new FormData();
    formdata.append("userText", formData.get('userQuestion'));
    
    var requestOptions = {
      method: 'POST',
      body: formdata,
      redirect: 'follow'
    };
    //http://185.251.89.78:56733/getanswer?userText=sdfjhjh
    fetch("http://185.251.89.78:56733/getanswer?userText=sdfjhjh", requestOptions)
      .then(response => response.text())
      .then(result => {
          const obj = JSON.parse(result);
          console.log(obj.answer);
          //console.log(obj);
          //let answer_html = new DOMParser().parseFromString(obj.answer, 'text/html');
          //answer_html.textContent;
          document.querySelector('#pageText').innerHTML = obj.answer;
          //console.log("asdasdasdasd");
          //console.log(obj.answer);
          //show_text();

          wrapperVideo.remove();
  
          if (textArea.value == 'привет'){
            videoSpace.insertAdjacentHTML('beforeend', `<video id="fon" autoplay="" controls="" src="videos/hello_first.mp4"></video>`); // И создаём видео внутри блока для видео
            console.log('Кейс1: Рекламка Meurch');
          } else if ( document.querySelector('#pageText').innerHTML == 'Вопрос, конечно, интересный, но переформулируйте его понятнее') {
            videoSpace.insertAdjacentHTML('beforeend', `<video id="fon" autoplay="" controls="" src="videos/hello_first.mp4"></video>`); // И создаём видео внутри блока для видео
            console.log('Кейс2: Ответ найден');
          } else{
            videoSpace.insertAdjacentHTML('beforeend', `<video id="fon" autoplay="" controls="" src="videos/hello_first.mp4" muted></video>`); // И создаём видео внутри блока для видео  
            console.log('Кейс3: Ответ не найден');
            //Озвучка полученного текста  
            talk ();
          }
          
          wrapperVideo = document.getElementById('fon');
          wrapperVideo.play();
      
      })
      .catch(error => console.log('error', error));
          

});

btnOk.addEventListener('click',function(){
  wrapperVideo.remove();
  videoSpace.insertAdjacentHTML('beforeend', `<video id="fon" autoplay="" controls="" src="videos/hello_first.mp4"></video>`); // И создаём видео внутри блока для видео
  wrapperVideo = document.getElementById('fon');
  wrapperVideo.play();
});

btnStop.addEventListener('click',function(){
  wrapperVideo.pause();
});


//Плавный вывод текста
var source,dest,len,now=0,delay=30,letters=1;
function show_text()
{
    source = document.getElementById("response");
    dest = document.getElementById("pageText");
    dest.innerHTML="";
    len = source.innerHTML.length;
    show();
}

function show()
{
    dest.innerHTML += source.innerHTML.substr(now,letters);
    now+=letters;

    if(now<len)
    	setTimeout("show()",delay);

}
//Плавный вывод текста



