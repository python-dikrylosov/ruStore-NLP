<link href="styles.css" rel="stylesheet" />

<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Виртуальный помощник RuStore</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0486qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <link rel="stylesheet" href="styles.css">
  </head>
  <body>

  <?include 'navigationWhite.php';?>
  
  <div style="width: 100%; background: #0077FF">
      <div style="display: flex; align-items: center; justify-content: center;">
          <img src="img/index/Красивая девушка в синем.png" style="width: 200px; margin-left: 50px"></img>
          <div>
          <h2 style="color: white; font-size: 18px;">Вопрос и ответ<h2>
              <h3 style="color: white; font-size: 16px;">Ответим на любой вопрос</h3>
             </div>
        </div>
    </div>
 
 <center>
 <div style="display: flex; max-width: 1200px;">  
    <div class="container my-4" style='width:50%; min-height: 500px; background-color: transparent;background-size: cover;'>
        <h1 style="margin-top: 130px">Интеллектуальный ассистент</h1>
        <br/>
        <a class="btn-ask btn btn-primary" onclick="window.location.href='chat.php';"style="margin-top:100px;">Начать</a>
    </div>
    <div class="container my-4" style='width:50%; min-height: 500px; background-image: url("img/index/Красивая девушка в синем.png");background-color: transparent;background-size: cover;'>
    </div>
</div>
</center>
    


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous"></script>
    <script src="main.js"></script>
  </body>
</html>

<script>
    //Активная вкладка
    document.querySelector('#menu-index').classList.add("active");
</script>

<?include 'footer.php';?>