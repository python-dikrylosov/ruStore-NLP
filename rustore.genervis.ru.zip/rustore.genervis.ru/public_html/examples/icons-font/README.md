# Bootstrap Icons Font

Include the [Bootstrap Icons](https://icons.getbootstrap.com) icon fonts via npm with Sass, Autoprefixer, and PurgeCSS.

## Edit in browser

[![Open in StackBlitz](https://developer.stackblitz.com/img/open_in_stackblitz.svg)](https://stackblitz.com/github/twbs/examples/tree/main/icons-font?file=index.html)

## How to use

```sh
git clone https://github.com/twbs/examples.git
cd examples/icons-font/
npm install
npm start
```
