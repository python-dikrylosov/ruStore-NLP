<template>
  <hr class="mt-5 mb-4">
  <p class="text-muted">Created and open sourced by the Bootstrap team. Licensed MIT.</p>
</template>
